#!/usr/bin/env python3

import os
import sys
import csv
import glob
from Bio import SeqIO

REGIONAL_WINDOW = 20

def nt_to_alignment_column(anc_nt, nt_pos):
    count = 0
    for i, base in enumerate(anc_nt):
        if base not in ("-", "!"):
            count += 1
            if count == nt_pos:
                return i
    return None


def codon_alignment_columns(anc_nt, aa_pos):
    nt_pos = (aa_pos - 1) * 3 + 1
    col_start = nt_to_alignment_column(anc_nt, nt_pos)
    if col_start is None:
        return None, None

    count = 0
    col_end = col_start
    while col_end < len(anc_nt) and count < 3:
        if anc_nt[col_end] not in ("-", "!"):
            count += 1
        col_end += 1

    return col_start, col_end


def get_codon_length(anc_nt):
    ungapped = sum(1 for b in anc_nt if b not in ("-", "!"))
    return ungapped // 3


def frameshift_positions_in_isolate(anc_nt, iso_nt):
    positions = []
    anc_nt_count = 0  

    for col, (anc_base, iso_base) in enumerate(zip(anc_nt, iso_nt)):
        if anc_base not in ("-", "!"):
            anc_nt_count += 1
        if iso_base == "!":
            codon_pos = (anc_nt_count - 1) // 3 + 1
            if not positions or positions[-1] != codon_pos:
                positions.append(codon_pos)

    return positions

def main():
    if len(sys.argv) != 4:
        sys.exit(
            "Usage: detect_frameshifts_macse.py "
            "<macse_output_dir> <mutation_list.tsv> <output.tsv>"
        )

    macse_dir     = sys.argv[1]
    mutation_file = sys.argv[2]
    output_file   = sys.argv[3]

    frameshift_targets = []
    try:
        with open(mutation_file) as fh:
            reader = csv.DictReader(fh, delimiter="\t")
            for row in reader:
                if row.get("mutation_type", "").strip() == "frameshift":
                    gene = row["gene"].strip()
                    pos  = int(row["aa_start"].strip())
                    frameshift_targets.append((gene, pos))
    except FileNotFoundError:
        sys.exit(f"ERROR: mutation list not found: {mutation_file}")

    if not frameshift_targets:
        print("No frameshift mutations in mutation list — nothing to do.",
              file=sys.stderr)
        sys.exit(0)

    unique_targets = sorted(set(frameshift_targets))
    print(
        f"Searching for {len(unique_targets)} unique frameshift position(s) "
        f"(regional window: ±{REGIONAL_WINDOW} codons):",
        file=sys.stderr,
    )
    for gene, pos in unique_targets:
        print(f"  {gene} codon {pos}", file=sys.stderr)

    results = []

    for gene, expected_pos in unique_targets:
        pattern = os.path.join(macse_dir, f"{gene}*_aligned_nt.fasta")
        aln_files = glob.glob(pattern)

        if not aln_files:
            print(f"  WARNING: no NT alignment files found for gene '{gene}'",
                  file=sys.stderr)
            continue

        tier1 = tier2 = tier3 = 0

        for aln_path in sorted(aln_files):
            records = list(SeqIO.parse(aln_path, "fasta"))
            if len(records) < 2:
                continue

            anc_nt    = str(records[0].seq)
            gene_len  = get_codon_length(anc_nt)
            region_lo = max(1, expected_pos - REGIONAL_WINDOW)
            region_hi = min(gene_len, expected_pos + REGIONAL_WINDOW)

            for rec in records[1:]:
                iso_nt = str(rec.seq)
                fs_positions = frameshift_positions_in_isolate(anc_nt, iso_nt)

                if not fs_positions:
                    continue

                if expected_pos in fs_positions:
                    results.append((gene, expected_pos, "exact", rec.id))
                    tier1 += 1
                    continue

                regional = [p for p in fs_positions if region_lo <= p <= region_hi]
                if regional:
                    closest = min(regional, key=lambda p: abs(p - expected_pos))
                    results.append((gene, closest, "regional", rec.id))
                    tier2 += 1
                    continue

                results.append((gene, fs_positions[0], "gene", rec.id))
                tier3 += 1

        print(
            f"  {gene} codon {expected_pos}: "
            f"exact={tier1}  regional={tier2}  gene={tier3}",
            file=sys.stderr,
        )

    with open(output_file, "w") as out:
        for gene, pos, tier, isolate_id in results:
            out.write(f"{gene}\t{pos}\t{tier}\t{isolate_id}\n")

    total = len(results)
    exact    = sum(1 for r in results if r[2] == "exact")
    regional = sum(1 for r in results if r[2] == "regional")
    gene_lvl = sum(1 for r in results if r[2] == "gene")
    print(
        f"\n✅ {total} frameshift hits written to {output_file}\n"
        f"   exact={exact}  regional={regional}  gene={gene_lvl}",
        file=sys.stderr,
    )


if __name__ == "__main__":
    main()
