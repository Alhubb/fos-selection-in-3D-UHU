#!/bin/bash

set -euo pipefail

GENES=/home/alasdair/3D_UHU_evo_analysis/WT_gene_fasta
GENOMES=/media/alasdair/External/3D_UHU/bakrep/fasta
OUTBASE=/media/alasdair/External/3D_UHU/minimap2_output
INDEX_DIR=/media/alasdair/External/3D_UHU/minimap2_indices

PRESET="asm20"
THREADS=4

mkdir -p "$INDEX_DIR" "$OUTBASE"

echo "==============================="
echo "Phase 1: Indexing genomes"
echo "==============================="

for g in "$GENOMES"/*.fna.gz; do
    [ -f "$g" ] || continue
    base=$(basename "$g" .fna.gz)
    idx="${INDEX_DIR}/${base}.mmi"

    if [ -f "$idx" ]; then
        echo "  Skipping (already indexed): $base"
        continue
    fi

    echo "  Indexing: $base"
    minimap2 -x "$PRESET" -d "$idx" "$g"
done

echo "✅ Indexing complete"
echo

echo "==============================="
echo "Phase 2: Mapping genes ($THREADS parallel jobs)"
echo "==============================="

for gene in "$GENES"/*.fasta; do
    [ -f "$gene" ] || continue

    gene_base=$(basename "$gene" .fasta)
    outdir="${OUTBASE}/${gene_base}_minimap_hits"
    mkdir -p "$outdir"

    echo "Processing gene: $gene_base"

    tmplist=$(mktemp)
    for idx in "$INDEX_DIR"/*.mmi; do
        [ -f "$idx" ] || continue
        base=$(basename "$idx" .mmi)
        paf="${outdir}/${base}.paf"
        [ -f "$paf" ] || echo "$idx"
    done > "$tmplist"

    total=$(wc -l < "$tmplist")
    echo "  $total mappings to run"

    xargs -a "$tmplist" -P "$THREADS" -I{} bash -c '
        idx="{}"
        base=$(basename "$idx" .mmi)
        paf="'"$outdir"'/${base}.paf"
        minimap2 -x "'"$PRESET"'" -c "$idx" "'"$gene"'" > "$paf"
    '

    rm -f "$tmplist"
    echo "✅ Finished gene: $gene_base"
    echo
done

echo "✅ Mapping complete"
