#!/bin/bash

set -euo pipefail

SOURCE="/media/alasdair/External/3D_UHU/bakrep/ecoli"
DEST="/media/alasdair/External/3D_UHU/bakrep/fasta"

mkdir -p "$DEST"

find "$SOURCE" -type f -print0 | while IFS= read -r -d '' file; do
    filename=$(basename "$file")

    if [ -e "$DEST/$filename" ]; then
        base="${filename%.*}"
        ext="${filename##*.}"
        counter=1
        while [ -e "$DEST/${base}_${counter}.${ext}" ]; do
            ((counter++))
        done
        newname="${base}_${counter}.${ext}"
        echo "  Name collision: renaming to $newname"
        cp "$file" "$DEST/$newname"
        rm "$file"
    else
        cp "$file" "$DEST/$filename"
        rm "$file"
    fi
done

echo "✅ Files moved to $DEST"
