#!/bin/bash
set -euo pipefail

BASE="/home/alasdair/3D_UHU_evo_analysis"
SCRIPTS="$BASE/scripts"

EXTRACTED="$BASE/extracted_genes"
WT="$BASE/WT_gene_fasta"
PER_GENE_FASTAS="$BASE/per_gene_fastas"
PER_GENE_FASTAS_DEDUP="$BASE/per_gene_fastas_dedup"
PER_GENE_FASTAS_CLEAN="$BASE/per_gene_fastas_clean"
MACSE_OUT="$BASE/macse_output"
MACSE_OUT_CLEAN="$BASE/macse_output_clean"
STOP_CALLS="$BASE/stop_calls"

MACSE_SUMMARY="$BASE/mutation_cds_macse_strict_summary.tsv"
FRAMESHIFTS="$BASE/frameshifts.tsv"
INDELS="$BASE/indels.tsv"
STOP_GENES="$BASE/stop_genes.tsv"

: "${MUTATION_LIST:?Need MUTATION_LIST — run: export MUTATION_LIST=/path/to/mutation_list.tsv}"

step() { echo; echo "── Step $1: $2 ──────────────────────────"; }
done_() { echo "   ✅ $1"; }
warn()  { echo "   ⚠  $1"; }

step "1" "Building per-gene FASTAs"
mkdir -p "$PER_GENE_FASTAS"

built=0; skipped=0
for dir in "$EXTRACTED"/*; do
    [ -d "$dir" ] || continue

    name=$(basename "$dir")
    core="${name%_minimap_hits}"
    lineage="${core##*_}"
    gene="${core%_*}"

    wt_fasta="$WT/${gene}_${lineage}.fasta"
    out_fasta="$PER_GENE_FASTAS/${gene}_${lineage}.fasta"

    if [ ! -f "$wt_fasta" ]; then
        warn "Missing WT for ${gene}_${lineage} — skipping"
        skipped=$((skipped + 1)); continue
    fi

    shopt -s nullglob
    files=( "$dir"/*.bakta."$gene".fasta )
    shopt -u nullglob

    if [ ${#files[@]} -eq 0 ]; then
        warn "No mutant CDS files in $dir — skipping"
        skipped=$((skipped + 1)); continue
    fi

    { cat "$wt_fasta"; echo
      for f in "${files[@]}"; do cat "$f"; echo; done
    } > "$out_fasta"
    built=$((built + 1))
done

done_ "$built gene/lineage FASTAs built${skipped:+, $skipped skipped}"

step "2" "Deduplicating per-gene FASTAs (exact duplicates only)"
mkdir -p "$PER_GENE_FASTAS_DEDUP"

if ! command -v seqkit &>/dev/null; then
    echo "ERROR: seqkit not found — cannot deduplicate" >&2
    exit 1
fi

dedup_failure=0

set +e 

shopt -s nullglob
for f in "$PER_GENE_FASTAS"/*.fasta; do
    base=$(basename "$f")
    gene_ref="${base%.fasta}"
    out="$PER_GENE_FASTAS_DEDUP/$base"

    seqkit rmdup -s "$f" > "$out" 2>/dev/null
    dedup_ok=$?

    if [ "$dedup_ok" -ne 0 ]; then
        warn "${gene_ref}: seqkit rmdup failed — copying as-is"
        cp "$f" "$out"
        dedup_failure=$((dedup_failure + 1))
        continue
    fi

    wt_header_text=$(grep "^>" "$f" | head -1 | sed 's/^>//')
    grep -qF "$wt_header_text" "$out" 2>/dev/null
    grep_rc=$?
    if [ "$grep_rc" -ne 0 ]; then
        wt_block=$(awk '/^>/{if(p)exit; p=1} p{print}' "$f")
        tmp=$(mktemp)
        { printf '%s\n' "$wt_block"; cat "$out"; } > "$tmp"
        mv "$tmp" "$out"
        warn "${gene_ref}: WT ancestor was removed — prepended back"
    fi

    n_in=$(grep -c "^>" "$f")
    n_out=$(grep -c "^>" "$out")
    removed=$((n_in - n_out))
    if [ "$removed" -gt 0 ]; then
        echo "   ${gene_ref}: ${n_in} → ${n_out} unique (${removed} removed)"
    else
        echo "   ${gene_ref}: ${n_in} → ${n_out} unique ✅"
    fi
done
shopt -u nullglob

set -e 

if [ "$dedup_failure" -gt 0 ]; then
    warn "$dedup_failure gene(s) could not be deduplicated — check seqkit installation"
fi

done_ "Deduplication complete"

step "3" "Cleaning per-gene FASTAs"

conda run -n python python \
    "$SCRIPTS/clean_gene_fastas.py" \
    "$PER_GENE_FASTAS_DEDUP" \
    "$PER_GENE_FASTAS_CLEAN" \
    2>&1

done_ "Cleaning complete"

step "4" "Running MACSE alignment (4 cores)"
mkdir -p "$MACSE_OUT"

find "$PER_GENE_FASTAS_CLEAN" -maxdepth 1 -type f -name "*.fasta" -print0 | \
xargs -0 -r -n 1 -P 4 bash -c '
    f="$1"
    base=$(basename "$f" .fasta)
    if [ -f "'"$MACSE_OUT"'/${base}_aligned_aa.fasta" ]; then
        echo "   ${base}: already aligned — skipping"
        exit 0
    fi
    echo "   Aligning: $base"
    conda run -n macse macse \
      -prog alignSequences \
      -seq "$f" \
      -out_AA "'"$MACSE_OUT"'/${base}_aligned_aa.fasta" \
      -out_NT "'"$MACSE_OUT"'/${base}_aligned_nt.fasta"
' _

done_ "MACSE alignments complete"

step "5" "Cleaning MACSE alignments (post-alignment gap + stop-lost filter)"

STOP_LOST_GENES=$(awk -F'\t' '$4=="stop_lost" {print $1}' "$MUTATION_LIST" | sort -u | paste -sd,)

conda run -n python python \
    "$SCRIPTS/clean_macse_alignments.py" \
    "$MACSE_OUT" \
    "$MACSE_OUT_CLEAN" \
    ${STOP_LOST_GENES:+--stop-lost-genes "$STOP_LOST_GENES"} \
    2>&1

done_ "MACSE alignment cleaning complete → $(basename "$MACSE_OUT_CLEAN")"

step "6" "Scanning MACSE alignments for mutations"

conda run -n python python \
    "$SCRIPTS/scan_mutations_cds_macse.py" \
    "$MACSE_OUT_CLEAN" \
    "$MUTATION_LIST" \
    > "$MACSE_SUMMARY"

done_ "MACSE summary → $(basename "$MACSE_SUMMARY")"

step "7" "Detecting position-specific frameshifts"

conda run -n python python \
    "$SCRIPTS/detect_frameshifts_macse.py" \
    "$MACSE_OUT_CLEAN" \
    "$MUTATION_LIST" \
    "$FRAMESHIFTS"

n=$(wc -l < "$FRAMESHIFTS")
done_ "$n frameshift hits → $(basename "$FRAMESHIFTS")"

step "8" "Detecting in-frame indels (delins / inframe_deletion)"

conda run -n python python \
    "$SCRIPTS/detect_indels_macse.py" \
    "$MACSE_OUT_CLEAN" \
    "$MUTATION_LIST" \
    "$INDELS"

n=$(wc -l < "$INDELS")
done_ "$n indel hits → $(basename "$INDELS")"

step "9" "Detecting stop-gain / stop-loss mutations"
mkdir -p "$STOP_CALLS"
> "$STOP_CALLS/stop_calls.tsv"

shopt -s nullglob
for f in "$PER_GENE_FASTAS_CLEAN"/*.fasta; do
    conda run -n python python \
        "$SCRIPTS/detect_stop_mutations.py" "$f" "$MUTATION_LIST" \
        >> "$STOP_CALLS/stop_calls.tsv"
done
shopt -u nullglob

awk 'NF >= 4 { print $1 "\t" $2 "\t" $3 "\t" $4 }' "$STOP_CALLS/stop_calls.tsv" \
    | sort -u > "$STOP_GENES"

n=$(wc -l < "$STOP_GENES")
done_ "$n stop events → $(basename "$STOP_GENES")"

step "10" "Screening predefined mutations"

conda run -n python python \
    "$SCRIPTS/screen_mutations.py" \
    --mutations   "$MUTATION_LIST" \
    --macse       "$MACSE_SUMMARY" \
    --frameshifts "$FRAMESHIFTS" \
    --indels      "$INDELS" \
    --stops       "$STOP_GENES" \
    --output      "$BASE/mutation_screen_results.tsv"

done_ "Results → mutation_screen_results.tsv"

step "11" "Extracting confirmed mutation sequences"

mkdir -p "$BASE/confirmed_sequences"

conda run -n python python \
    "$SCRIPTS/extract_confirmed_sequences.py" \
    "$MACSE_OUT_CLEAN" \
    "$MACSE_SUMMARY" \
    "$MUTATION_LIST" \
    "$BASE/confirmed_sequences" \
    --frameshifts     "$FRAMESHIFTS" \
    --stops           "$STOP_GENES" \
    --per-gene-fastas "$PER_GENE_FASTAS_CLEAN" \
    --screen-results  "$BASE/mutation_screen_results.tsv" \
    --any

done_ "Confirmed sequences → confirmed_sequences/"

# ============================================================

echo
echo "══════════════════════════════════════════"
echo "  ✅  PIPELINE COMPLETE"
echo "  ➡   $BASE/mutation_screen_results.tsv"
echo "══════════════════════════════════════════"
echo
