#!/usr/bin/env python3

import sys
import gzip
import io
from Bio import SeqIO

VALID = set("ACGTNacgtn")


def reverse_complement(seq):
    complement = str.maketrans("ACGTacgtNn", "TGCAtgcaNn")
    return seq.translate(complement)[::-1]


def parse_best_hit(paf_file):
    MIN_HIT_FRACTION = 0.5

    best = None
    best_matches = -1

    with open(paf_file) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue

            fields = line.split("\t")
            if len(fields) < 12:
                continue

            try:
                query_len = int(fields[1])
                mapq      = int(fields[11])
                matches   = int(fields[9])  
                tname     = fields[5]
                strand    = fields[4]
                tstart    = int(fields[7])
                tend      = int(fields[8])
            except (ValueError, IndexError):
                continue

            if mapq == 0:
                continue

            hit_span = tend - tstart
            if query_len > 0 and hit_span < query_len * MIN_HIT_FRACTION:
                continue

            if matches > best_matches:
                best_matches = matches
                best = (tname, strand, tstart, tend)

    return best


def read_assembly(assembly_file):
    if assembly_file == "/dev/stdin":
        raw = sys.stdin.buffer.read()
        if raw[:2] == b"\x1f\x8b":
            handle = io.TextIOWrapper(gzip.open(io.BytesIO(raw)))
        else:
            handle = io.StringIO(raw.decode())
    else:
        if assembly_file.endswith(".gz"):
            handle = io.TextIOWrapper(gzip.open(assembly_file, "rb"))
        else:
            handle = open(assembly_file)

    records = {rec.id: str(rec.seq) for rec in SeqIO.parse(handle, "fasta")}
    return records


def extract_region(records, tname, strand, start, end):
    if end < start:
        start, end = end, start

    seq = records.get(tname) or records.get(tname.split()[0])
    if seq is None:
        return None

    extracted = seq[start:end]

    if strand == "-":
        extracted = reverse_complement(extracted)

    return extracted


def main():
    if len(sys.argv) != 4:
        print(
            "Usage: extract_gene_from_paf.py "
            "<paf> <assembly.fna[.gz] | /dev/stdin> <output.fasta>",
            file=sys.stderr,
        )
        sys.exit(1)

    paf_file      = sys.argv[1]
    assembly_file = sys.argv[2]
    output_file   = sys.argv[3]

    records = read_assembly(assembly_file)

    hit = parse_best_hit(paf_file)
    if hit is None:
        print(f"[WARN] No valid hits in {paf_file}", file=sys.stderr)
        sys.exit(0)

    tname, strand, start, end = hit

    seq = extract_region(records, tname, strand, start, end)

    if seq is None:
        print(f"[WARN] Contig {tname} not found in assembly", file=sys.stderr)
        sys.exit(0)

    if len(seq) == 0:
        print(f"[WARN] Empty sequence extracted from {tname}", file=sys.stderr)
        sys.exit(0)

    if any(base not in VALID for base in seq):
        print(
            f"[WARN] Illegal characters in extracted sequence from {tname}",
            file=sys.stderr,
        )
        sys.exit(0)

    with open(output_file, "w") as out:
        out.write(f">{tname}:{start}-{end}({strand})\n")
        out.write(seq + "\n")


if __name__ == "__main__":
    main()
