#!/usr/bin/env python3

import sys
import re
import csv

THREE_TO_ONE = {
    "Ala": "A", "Arg": "R", "Asn": "N", "Asp": "D", "Cys": "C",
    "Gln": "Q", "Glu": "E", "Gly": "G", "His": "H", "Ile": "I",
    "Leu": "L", "Lys": "K", "Met": "M", "Phe": "F", "Pro": "P",
    "Ser": "S", "Thr": "T", "Trp": "W", "Tyr": "Y", "Val": "V",
    "Ter": "*", "Stop": "*",
}


def three_to_one(aa3):
    return THREE_TO_ONE.get(aa3.capitalize(), "")


def parse_protein_change(p_change):

    p = p_change.lstrip("p.")

    m = re.match(r'([A-Za-z]{3})(\d+)fs', p)
    if m:
        ref = three_to_one(m.group(1))
        return int(m.group(2)), int(m.group(2)), "frameshift", ref, ""

    if p.startswith("Ter") or p.startswith("Stop") or "ext" in p:
        m = re.search(r'(\d+)', p)
        pos = int(m.group(1)) if m else 0
        return pos, pos, "stop_lost", "*", ""

    m = re.match(r'([A-Za-z]{3})(\d+)\*$', p)
    if m:
        ref = three_to_one(m.group(1))
        return int(m.group(2)), int(m.group(2)), "stop_gained", ref, ""

    m = re.match(r'([A-Za-z]{3})(\d+)_([A-Za-z]{3})(\d+)delins([A-Za-z]+)', p)
    if m:
        ref = three_to_one(m.group(1))
        inserted_raw = m.group(5)
        inserted = three_to_one(inserted_raw[:3]) if len(inserted_raw) >= 3 else inserted_raw[0].upper()
        return int(m.group(2)), int(m.group(4)), "delins", ref, inserted

    m = re.match(r'([A-Za-z]{3})(\d+)_([A-Za-z]{3})(\d+)del$', p)
    if m:
        ref = three_to_one(m.group(1))
        return int(m.group(2)), int(m.group(4)), "inframe_deletion", ref, ""

    m = re.match(r'([A-Za-z]{3})(\d+)del$', p)
    if m:
        ref = three_to_one(m.group(1))
        return int(m.group(2)), int(m.group(2)), "inframe_deletion", ref, ""

    m = re.match(r'([A-Za-z]{3})(\d+)([A-Za-z]{3})$', p)
    if m:
        ref  = three_to_one(m.group(1))
        dest = three_to_one(m.group(3))
        return int(m.group(2)), int(m.group(2)), "missense", ref, dest

    return None, None, "unknown", "", ""


def parse_effect(effect, aa_pos_field):

    nt_change = ""
    p_change  = ""

    for part in effect.split():
        if part.startswith("c."):
            nt_change = part
        elif part.startswith("p."):
            p_change = part

    if p_change:
        aa_start, aa_end, mut_type, ref_aa, expected = parse_protein_change(p_change)
        if mut_type != "unknown":
            return aa_start, aa_end, mut_type, ref_aa, expected, nt_change

    effect_lower = effect.lower()
    if "frameshift" in effect_lower:
        pos = _aa_pos_start(aa_pos_field)
        return pos, pos, "frameshift", "", "", nt_change
    if "stop_gained" in effect_lower or "stop_gain" in effect_lower:
        pos = _aa_pos_start(aa_pos_field)
        return pos, pos, "stop_gained", "", "", nt_change
    if "stop_lost" in effect_lower or "stop_loss" in effect_lower:
        pos = _aa_pos_start(aa_pos_field)
        return pos, pos, "stop_lost", "", "", nt_change
    if "inframe_deletion" in effect_lower or "conservative_inframe_deletion" in effect_lower:
        pos = _aa_pos_start(aa_pos_field)
        return pos, pos, "inframe_deletion", "", "", nt_change
    if "inframe_insertion" in effect_lower:
        pos = _aa_pos_start(aa_pos_field)
        return pos, pos, "inframe_insertion", "", "", nt_change
    if "missense" in effect_lower:
        pos = _aa_pos_start(aa_pos_field)
        return pos, pos, "missense", "", "", nt_change

    print(
        f"WARNING: could not parse EFFECT '{effect}', "
        f"using AA_POS={aa_pos_field}, type=unknown",
        file=sys.stderr,
    )
    return _aa_pos_start(aa_pos_field), _aa_pos_start(aa_pos_field), "unknown", "", "", nt_change


def _aa_pos_start(aa_pos_field):
    try:
        return int(str(aa_pos_field).split("/")[0])
    except (ValueError, IndexError):
        return 0


def main():
    if len(sys.argv) != 3:
        sys.exit("Usage: convert_snippy_to_mutation_list.py <snippy.tsv> <output.tsv>")

    in_path  = sys.argv[1]
    out_path = sys.argv[2]

    written = 0
    skipped = 0

    with open(in_path) as fh_in, open(out_path, "w", newline="") as fh_out:
        reader = csv.DictReader(fh_in, delimiter="\t")

        required = {"GENE", "AA_POS", "EFFECT", "FTYPE"}
        missing = required - set(reader.fieldnames or [])
        if missing:
            sys.exit(f"ERROR: input TSV is missing columns: {missing}")

        writer = csv.writer(fh_out, delimiter="\t", lineterminator="\n")
        writer.writerow([
            "gene", "aa_start", "aa_end", "mutation_type",
            "expected", "ref_aa", "nt_change"
        ])

        for lineno, row in enumerate(reader, start=2):
            if row.get("FTYPE", "").strip() != "CDS":
                skipped += 1
                continue

            gene   = row["GENE"].strip()
            effect = row["EFFECT"].strip()
            aa_pos = row["AA_POS"].strip()

            if not gene or not effect:
                print(f"WARNING: line {lineno} missing GENE or EFFECT, skipping",
                      file=sys.stderr)
                skipped += 1
                continue

            aa_start, aa_end, mut_type, ref_aa, expected, nt_change = \
                parse_effect(effect, aa_pos)

            if mut_type == "unknown":
                skipped += 1
                continue

            writer.writerow([
                gene, aa_start, aa_end, mut_type,
                expected, ref_aa, nt_change
            ])
            written += 1

    print(f"✅ Done — {written} mutations written to {out_path}")
    if skipped:
        print(f"⚠  {skipped} rows skipped (non-CDS or unparseable)")


if __name__ == "__main__":
    main()
