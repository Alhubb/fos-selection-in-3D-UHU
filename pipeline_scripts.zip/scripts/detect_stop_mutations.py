#!/usr/bin/env python3

import sys
import os
from Bio import SeqIO
from Bio.Seq import Seq

REGIONAL_WINDOW = 20


def translate_nt(nt_str):
    seq = nt_str.upper().replace("-", "").replace("!", "")
    remainder = len(seq) % 3
    if remainder:
        seq = seq[:-remainder]
    return str(Seq(seq).translate(table=11))


def main(nt_fasta, called_positions=None):
    records = list(SeqIO.parse(nt_fasta, "fasta"))
    if len(records) < 2:
        return

    gene = os.path.basename(nt_fasta)
    gene = gene.replace(".fasta", "").replace(".fna", "")
    gene = gene.rsplit("_", 1)[0]

    wt_aa = translate_nt(str(records[0].seq))
    wt_stop_pos = wt_aa.find("*") + 1 if "*" in wt_aa else len(wt_aa) + 1

    gene_calls = called_positions.get(gene, {}) if called_positions else {}
    called_gain_pos = gene_calls.get("stop_gained")
    called_lost_pos = gene_calls.get("stop_lost")

    for rec in records[1:]:
        aa = translate_nt(str(rec.seq))
        # 1-based position of first stop in isolate
        iso_stop = aa.find("*") + 1 if "*" in aa else None

        if iso_stop is not None and iso_stop < wt_stop_pos:
            pos = iso_stop
            if called_gain_pos is not None:
                dist = abs(pos - called_gain_pos)
                if dist == 0:
                    tier = "exact"
                elif dist <= REGIONAL_WINDOW:
                    tier = "regional"
                else:
                    tier = "gene"
            else:
                tier = "gene"
            print(f"{gene}\t{pos}\t{tier}\t{rec.id}")
            continue

        if iso_stop is None or iso_stop > wt_stop_pos:
            pos = wt_stop_pos 
            if called_lost_pos is not None:
                dist = abs(pos - called_lost_pos)
                if dist == 0:
                    tier = "exact"
                elif dist <= REGIONAL_WINDOW:
                    tier = "regional"
                else:
                    tier = "gene"
            else:
                tier = "gene"
            print(f"{gene}\t{pos}\t{tier}\t{rec.id}")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit("Usage: detect_stop_mutations.py <nucleotide_cds_fasta> [mutation_list.tsv]")

    nt_fasta = sys.argv[1]
    called_positions = {}

    if len(sys.argv) >= 3:
        import csv
        with open(sys.argv[2]) as fh:
            reader = csv.DictReader(fh, delimiter="\t")
            for row in reader:
                mtype = row.get("mutation_type","").strip()
                if mtype in ("stop_gained","stop_lost"):
                    g = row.get("gene","").strip()
                    try:
                        pos = int(row["aa_start"])
                    except (KeyError, ValueError):
                        continue
                    called_positions.setdefault(g, {})[mtype] = pos

    main(nt_fasta, called_positions)

