#!/usr/bin/env python3

import os
import sys
import glob

MIN_FRACTION = 0.5

MIN_ABS_LENGTH = 100

VALID = set("ACGTNacgtn")

def parse_fasta(path):
    records = []
    with open(path) as fh:
        current_header, current_seq = None, []
        for line in fh:
            line = line.rstrip()
            if line.startswith(">"):
                if current_header is not None:
                    records.append((current_header, "".join(current_seq)))
                current_header = line[1:]
                current_seq = []
            else:
                current_seq.append(line)
        if current_header is not None:
            records.append((current_header, "".join(current_seq)))
    return records


def write_fasta(records, path):
    with open(path, "w") as fh:
        for header, seq in records:
            fh.write(f">{header}\n{seq}\n")


def clean_seq(seq):
    return seq.replace("-", "").replace("!", "").upper()


def is_valid(seq, wt_len):
    raw = clean_seq(seq)

    if len(raw) < MIN_ABS_LENGTH:
        return False, f"too_short ({len(raw)} nt)"

    if len(raw) < wt_len * MIN_FRACTION:
        return False, f"short_fraction ({len(raw)}/{wt_len} = {len(raw)/wt_len:.1%})"

    invalid = set(raw) - VALID
    if invalid:
        return False, f"non_IUPAC ({invalid})"

    return True, "ok"

def main():
    if len(sys.argv) != 3:
        sys.exit("Usage: clean_gene_fastas.py <input_dir> <output_dir>")

    in_dir  = sys.argv[1]
    out_dir = sys.argv[2]
    os.makedirs(out_dir, exist_ok=True)

    fasta_files = sorted(glob.glob(os.path.join(in_dir, "*.fasta")))
    if not fasta_files:
        sys.exit(f"ERROR: no .fasta files found in {in_dir}")

    total_in = total_out = total_removed = 0

    for fasta_path in fasta_files:
        base     = os.path.basename(fasta_path)
        out_path = os.path.join(out_dir, base)

        records = parse_fasta(fasta_path)
        if len(records) < 2:
            write_fasta(records, out_path)
            continue

        wt_header, wt_seq = records[0]
        wt_len = len(clean_seq(wt_seq))

        kept    = []
        removed = []

        for header, seq in records[1:]:
            keep, reason = is_valid(seq, wt_len)
            if keep:
                kept.append((header, seq))
            else:
                removed.append((header, reason))

        n_in      = len(records) - 1
        n_kept    = len(kept)
        n_removed = len(removed)

        total_in      += n_in
        total_out     += n_kept
        total_removed += n_removed

        write_fasta([(wt_header, wt_seq)] + kept, out_path)

        gene_ref = base.replace(".fasta", "")
        if n_removed > 0:
            print(f"  {gene_ref}: {n_in} → {n_kept} "
                  f"(removed {n_removed})", file=sys.stderr)
            for h, r in removed[:3]:  
                print(f"    ✗ {h[:60]}: {r}", file=sys.stderr)
            if n_removed > 3:
                print(f"    ... and {n_removed - 3} more", file=sys.stderr)
        else:
            print(f"  {gene_ref}: {n_in} → {n_kept} ✅", file=sys.stderr)

    print(f"\n✅ Cleaning complete: "
          f"{total_in} sequences in → "
          f"{total_out} kept, "
          f"{total_removed} removed",
          file=sys.stderr)


if __name__ == "__main__":
    main()
