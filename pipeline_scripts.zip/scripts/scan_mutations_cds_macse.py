#!/usr/bin/env python3

import os
import sys
import csv
import glob
from Bio import SeqIO

DEBUG = False  

DELINS_FLANK = 5

MACSE_TYPES = {"missense", "inframe_deletion", "delins"}

def load_mutations(tsv_file):
    mutations = []

    with open(tsv_file) as fh:
        reader = csv.DictReader(fh, delimiter="\t")
        for row in reader:
            gene  = row.get("gene", "").strip()
            mtype = row.get("mutation_type", "").strip()
            if not gene or not mtype:
                continue
            try:
                start = int(row["aa_start"])
                end   = int(row["aa_end"])
            except (KeyError, ValueError):
                continue

            expected_raw = row.get("expected", "").strip()
            expected = None if expected_raw in ("", ".", "NA", "None") else expected_raw

            mutations.append((gene, start, end, mtype, expected))

    return mutations

def ungapped_to_alignment_index(seq, pos):
    count = 0
    for i, aa in enumerate(seq):
        if aa not in ("-", "!"):
            count += 1
            if count == pos:
                return i
    return None


def get_alignment_columns(anc_seq, start, end):
    col_start = ungapped_to_alignment_index(anc_seq, start)
    if col_start is None:
        return None, None

    span = end - start + 1
    count = 0
    col_end = col_start
    while col_end < len(anc_seq) and count < span:
        if anc_seq[col_end] not in ("-", "!"):
            count += 1
        col_end += 1

    return col_start, col_end

def get_isolate_residue(anc, iso, start, end):
    c0, c1 = get_alignment_columns(anc, start, end)
    if c0 is None:
        return "?"
    return iso[c0:c1].replace("-", "").replace("!", "")


def confirm_any_missense(anc, iso, start, end):
    c0, c1 = get_alignment_columns(anc, start, end)
    if c0 is None:
        return False
    anc_w = anc[c0:c1].replace("-", "").replace("!", "")
    iso_w = iso[c0:c1].replace("-", "").replace("!", "")
    if not iso_w:
        return False
    return anc_w != iso_w


def confirm_indel(anc, iso, start, end, inserted=None):
    c0, c1 = get_alignment_columns(anc, start, end)
    if c0 is None:
        return False

    anc_w = anc[c0:c1]
    iso_w = iso[c0:c1]

    anc_ungapped = len([a for a in anc_w if a not in ("-", "!")])
    iso_gaps     = sum(1 for a in iso_w if a in ("-", "!"))
    expected_del = end - start + 1

    if anc_ungapped < expected_del * 0.8:
        return False
    if iso_gaps < expected_del:
        return False

    if inserted:
        flank_start = max(0, c0 - DELINS_FLANK)
        flank_end   = min(len(iso), c1 + DELINS_FLANK)
        iso_wide = iso[flank_start:flank_end].replace("-", "").replace("!", "")
        return inserted in iso_wide

    return True

def main():
    if len(sys.argv) < 3:
        sys.exit("Usage: scan_mutations_cds_macse.py <macse_dir> <mutation_list.tsv> [--debug]")

    macse_dir     = sys.argv[1]
    mutation_file = sys.argv[2]
    debug         = "--debug" in sys.argv

    try:
        mutations = load_mutations(mutation_file)
    except FileNotFoundError:
        sys.exit(f"ERROR: mutation list not found: {mutation_file}")

    if not mutations:
        sys.exit("ERROR: no mutations loaded from mutation list")

    print(f"[INFO] Loaded {len(mutations)} mutations from {mutation_file}",
          file=sys.stderr)

    aa_files = glob.glob(os.path.join(macse_dir, "*_aligned_aa.fasta"))
    print(f"[INFO] Found {len(aa_files)} AA alignment files", file=sys.stderr)

    present_exact = {(g, s, e, m): 0 for g, s, e, m, _ in mutations}
    present_any   = {(g, s, e, m): 0 for g, s, e, m, _ in mutations}

    for g, s, e, m, x in mutations:
        if m not in MACSE_TYPES:
            continue

        matching = [f for f in aa_files
                    if os.path.basename(f).startswith(g + "_")
                    or os.path.basename(f).startswith(g + "_aligned")]
        if not matching:
            matching = [f for f in aa_files
                        if g.lower() in os.path.basename(f).lower()]

        print(f"[INFO] {g} {s}-{e} ({m}): matched {len(matching)} file(s)",
              file=sys.stderr)

        for aln in matching:
            records = list(SeqIO.parse(aln, "fasta"))
            if len(records) < 2:
                continue

            anc = str(records[0].seq)

            for r in records[1:]:
                iso = str(r.seq)

                if m == "missense":
                    res     = get_isolate_residue(anc, iso, s, e)
                    anc_res = get_isolate_residue(anc, anc, s, e)

                    if x is None:
                        if confirm_any_missense(anc, iso, s, e):
                            present_exact[(g, s, e, m)] = 1
                    else:
                        if res == x:
                            present_exact[(g, s, e, m)] = 1

                    if confirm_any_missense(anc, iso, s, e):
                        present_any[(g, s, e, m)] = 1

                    if debug:
                        match_str = "EXACT" if (res == x) else ("any_missense" if res != anc_res else "no_change")
                        print(f"DEBUG {g}:{s} WT='{anc_res}' iso='{res}' expected='{x}' → {match_str}",
                              file=sys.stderr)

                elif m in ("inframe_deletion", "delins"):
                    if confirm_indel(anc, iso, s, e, x):
                        present_any[(g, s, e, m)] = 1
                        if debug:
                            print(f"DEBUG {m} {g} {s}-{e}: confirmed in {r.id}",
                                  file=sys.stderr)

    print("gene\taa_start\taa_end\tmutation_type\texact_missense\tany_missense\tmacse_indel_confirmed")
    for g, s, e, m, _ in mutations:
        exact_missense       = present_exact.get((g,s,e,m), 0) if m == "missense" else 0
        any_missense         = present_any.get((g,s,e,m), 0)   if m == "missense" else 0
        macse_indel_confirmed = present_any.get((g,s,e,m), 0)  if m in ("inframe_deletion", "delins") else 0
        print(f"{g}\t{s}\t{e}\t{m}\t{exact_missense}\t{any_missense}\t{macse_indel_confirmed}")


if __name__ == "__main__":
    main()
