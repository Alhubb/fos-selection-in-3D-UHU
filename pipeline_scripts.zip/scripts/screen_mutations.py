#!/usr/bin/env python3

import argparse
import csv
import sys


def read_macse_hits(macse_file):
    exact_missense_hits = set()
    any_missense_hits   = set()
    macse_indel_hits    = set()
    try:
        with open(macse_file) as fh:
            reader = csv.DictReader(fh, delimiter="\t")
            for row in reader:
                try:
                    key = (
                        row["gene"],
                        int(row["aa_start"]),
                        int(row["aa_end"]),
                        row["mutation_type"],
                    )
                    if int(row.get("exact_missense", 0)):
                        exact_missense_hits.add(key)
                    if int(row.get("any_missense", 0)):
                        any_missense_hits.add(key)
                    if int(row.get("macse_indel_confirmed", 0)):
                        macse_indel_hits.add(key)
                except (KeyError, ValueError):
                    continue
    except FileNotFoundError:
        print(f"WARNING: {macse_file} not found", file=sys.stderr)
    return exact_missense_hits, any_missense_hits, macse_indel_hits


def read_frameshift_hits(path):
    exact_hits    = set()
    regional_hits = set()
    gene_hits     = set()

    try:
        with open(path) as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                parts = line.split("\t")
                if len(parts) < 3:
                    continue
                gene = parts[0].strip()
                try:
                    pos = int(parts[1].strip())
                except ValueError:
                    continue
                tier = parts[2].strip() if len(parts) > 2 else "gene"

                if tier == "exact":
                    exact_hits.add((gene, pos))
                elif tier == "regional":
                    regional_hits.add((gene, pos))
                else:
                    gene_hits.add(gene)

    except FileNotFoundError:
        print(f"WARNING: {path} not found", file=sys.stderr)

    return exact_hits, regional_hits, gene_hits


def read_indel_hits(path):
    exact_deletion_hits = set()
    regional_hits       = set()
    gene_hits           = set()

    try:
        with open(path) as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                parts = line.split("\t")
                if len(parts) < 3:
                    continue
                gene = parts[0].strip()
                try:
                    pos = int(parts[1].strip())
                except ValueError:
                    continue
                tier = parts[2].strip()

                if tier == "exact_deletion":
                    exact_deletion_hits.add((gene, pos))
                elif tier == "regional":
                    regional_hits.add(gene)
                else:
                    gene_hits.add(gene)
    except FileNotFoundError:
        print(f"WARNING: {path} not found", file=sys.stderr)

    return exact_deletion_hits, regional_hits, gene_hits


def read_stop_hits(path):
    exact_hits    = set()
    regional_hits = set()
    gene_hits     = set()

    try:
        with open(path) as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                parts = line.split("\t")

                if len(parts) >= 4:
                    gene = parts[0].strip()
                    try:
                        pos = int(parts[1].strip())
                    except ValueError:
                        continue
                    tier = parts[2].strip()
                    if tier == "exact":
                        exact_hits.add((gene, pos))
                    elif tier == "regional":
                        regional_hits.add((gene, pos))
                    else:
                        gene_hits.add(gene)

                elif len(parts) == 3:
                    gene = parts[0].strip()
                    gene_hits.add(gene)

    except FileNotFoundError:
        print(f"WARNING: {path} not found", file=sys.stderr)

    return exact_hits, regional_hits, gene_hits


REGIONAL_WINDOW = 20 


def main(args):
    exact_missense_hits, any_missense_hits, macse_indel_hits = read_macse_hits(args.macse)
    fs_exact, fs_regional, fs_gene  = read_frameshift_hits(args.frameshifts)
    ind_exact_del, ind_regional, ind_gene = read_indel_hits(args.indels)
    stop_exact, stop_regional, stop_gene  = read_stop_hits(args.stops)

    out = open(args.output, "w") if args.output else sys.stdout

    writer = csv.writer(out, delimiter="\t", lineterminator="\n")
    writer.writerow([
        "gene", "aa_start", "aa_end", "mutation_type",
        "exact_missense", "any_missense",
        "exact_frameshift", "regional_frameshift", "gene_frameshift",
        "exact_deletion", "regional_indel", "gene_indel",
        "exact_stop", "regional_stop", "gene_stop",
        "final_confirmed",
    ])

    try:
        with open(args.mutations) as fh:
            reader = csv.DictReader(fh, delimiter="\t")
            for lineno, row in enumerate(reader, start=2):
                try:
                    gene      = row["gene"]
                    aa_start  = int(row["aa_start"])
                    aa_end    = int(row["aa_end"])
                    mut_type  = row["mutation_type"]
                except (KeyError, ValueError) as e:
                    print(
                        f"WARNING: skipping malformed row {lineno} in "
                        f"{args.mutations}: {e}",
                        file=sys.stderr,
                    )
                    continue

                norm_type = {
                    "stop_gain":   "stop_gained",
                    "stop_gained": "stop_gained",
                    "stop_loss":   "stop_lost",
                    "stop_lost":   "stop_lost",
                }.get(mut_type, mut_type)
                macse_key = (gene, aa_start, aa_end, mut_type)

                exact_missense = int(mut_type == "missense" and macse_key in exact_missense_hits)
                any_missense   = int(mut_type == "missense" and macse_key in any_missense_hits)

                is_fs = mut_type == "frameshift"
                exact_fs    = int(is_fs and (gene, aa_start) in fs_exact)
                regional_fs = int(is_fs and not exact_fs
                                  and any(g == gene and abs(p - aa_start) <= REGIONAL_WINDOW
                                          for g, p in fs_regional))
                gene_fs     = int(is_fs and not exact_fs and not regional_fs
                                  and gene in fs_gene)

                is_indel = mut_type in ("delins", "inframe_deletion")
                centre   = (aa_start + aa_end) // 2
                exact_del    = int(is_indel and (
                                   (gene, centre) in ind_exact_del
                                   or macse_key in macse_indel_hits
                               ))
                regional_ind = int(is_indel and not exact_del
                                   and gene in ind_regional)
                gene_ind     = int(is_indel and not exact_del
                                   and not regional_ind
                                   and gene in ind_gene)

                is_stop = norm_type in ("stop_gained", "stop_lost")
                exact_stop    = int(is_stop and (gene, aa_start) in stop_exact)
                regional_stop = int(is_stop and not exact_stop
                                    and any(g == gene and abs(p - aa_start) <= REGIONAL_WINDOW
                                            for g, p in stop_regional))
                gene_stop     = int(is_stop and not exact_stop and not regional_stop
                                    and gene in stop_gene)

                final = int(bool(
                    exact_missense or any_missense
                    or exact_fs or regional_fs or gene_fs
                    or exact_del or regional_ind or gene_ind
                    or exact_stop or regional_stop or gene_stop
                ))

                writer.writerow([
                    gene, aa_start, aa_end, mut_type,
                    exact_missense, any_missense,
                    exact_fs, regional_fs, gene_fs,
                    exact_del, regional_ind, gene_ind,
                    exact_stop, regional_stop, gene_stop,
                    final,
                ])
    finally:
        if args.output:
            out.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Screen predefined mutations against pipeline evidence"
    )
    parser.add_argument("--mutations",   required=True, help="Mutation list TSV")
    parser.add_argument("--macse",       required=True, help="MACSE mutation summary TSV")
    parser.add_argument("--frameshifts", required=True, help="Frameshift hits TSV (detect_frameshifts_macse.py)")
    parser.add_argument("--indels",      required=True, help="Indel hits TSV (detect_indels_macse.py)")
    parser.add_argument("--stops",       required=True, help="Stop mutation TSV")
    parser.add_argument("--output",      default=None,  help="Output file (default: stdout)")
    main(parser.parse_args())
